package com.example.aayam;

class CarRecyclerViewItem {
    public CarRecyclerViewItem(String bmw, int frontpage) {

    }
}
